$(function(){
   
    AOS .init({
        easing:'ease',
        duration:1000,
    })
})