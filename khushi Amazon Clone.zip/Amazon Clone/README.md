# PrimeVideo_LoginPage_Clone
Prime Video Login Page Clone Using HTML,CSS AND JAVASCRIPT
